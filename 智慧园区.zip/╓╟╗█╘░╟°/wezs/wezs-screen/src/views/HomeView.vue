<script setup>

</script>

<template>
  <main>
    首页
  </main>
</template>
