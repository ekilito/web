<script setup>
import { RouterView } from 'vue-router'

</script>

<template>
  <!-- 路由渲染的位置 路由出口 -->
  <RouterView />
</template>

